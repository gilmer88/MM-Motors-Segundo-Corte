/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mm.motors;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author gillmer
 */
public class ConexionBD {
    
    public static Connection conectar() throws SQLException {
        String url = "jdbc:postgresql://localhost:5432/mm_motors";
        String usuario = "postgres";
        String clave = "cambiar_clave";
        
        return DriverManager.getConnection(url, usuario, clave);
    }
    
}   

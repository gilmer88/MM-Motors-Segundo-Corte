/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mm.motors;

/**
 *
 * @author gillmer
 */
public class MMMotors {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        try (java.sql.Connection conexion = ConexionBD.conectar()) {
        System.out.println("Conexión a PostgreSQL exitosa.");
}       catch (java.sql.SQLException ex) {
        System.out.println("Error de conexión: " + ex.getMessage());
}
        
        javax.swing.SwingUtilities.invokeLater(() -> 
        {
            new VentanaPrincipal().setVisible(true);
        });
        
    }
    
}

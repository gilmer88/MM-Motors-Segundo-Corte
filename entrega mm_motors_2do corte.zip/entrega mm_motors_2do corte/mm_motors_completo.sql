--
-- PostgreSQL database dump
--

\restrict dICQeqiYgCs5QwipfNXsUAD9BYIi1AmUIlmiTXqrDg8QQigvnfxfgxlgnvcPquJ

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: clientes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes (
    documento character varying(20) NOT NULL,
    nombres character varying(80) NOT NULL,
    apellidos character varying(80) NOT NULL,
    telefono character varying(20),
    correo character varying(120)
);


--
-- Name: detalle_repuestos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.detalle_repuestos (
    numero_orden integer NOT NULL,
    codigo_repuesto character varying(30) NOT NULL,
    cantidad integer NOT NULL,
    precio_unitario numeric(12,2) NOT NULL,
    CONSTRAINT ck_detalle_repuestos_cantidad CHECK ((cantidad > 0)),
    CONSTRAINT ck_detalle_repuestos_precio CHECK ((precio_unitario >= (0)::numeric))
);


--
-- Name: mano_obra; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mano_obra (
    id_mano_obra integer NOT NULL,
    numero_orden integer NOT NULL,
    descripcion character varying(500) NOT NULL,
    valor numeric(12,2) NOT NULL,
    CONSTRAINT ck_mano_obra_valor CHECK ((valor >= (0)::numeric))
);


--
-- Name: mano_obra_id_mano_obra_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.mano_obra ALTER COLUMN id_mano_obra ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.mano_obra_id_mano_obra_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ordenes_trabajo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ordenes_trabajo (
    numero_orden integer NOT NULL,
    placa character varying(6) NOT NULL,
    fecha_ingreso timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    motivo_ingreso text NOT NULL,
    estado character varying(20) DEFAULT 'pendiente'::character varying NOT NULL,
    CONSTRAINT ck_ordenes_trabajo_estado CHECK (((estado)::text = ANY ((ARRAY['pendiente'::character varying, 'en proceso'::character varying, 'finalizada'::character varying, 'cancelada'::character varying])::text[])))
);


--
-- Name: ordenes_trabajo_numero_orden_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ordenes_trabajo ALTER COLUMN numero_orden ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ordenes_trabajo_numero_orden_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: repuestos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repuestos (
    codigo character varying(30) NOT NULL,
    nombre character varying(100) NOT NULL,
    precio numeric(12,2) NOT NULL,
    existencias integer DEFAULT 0 NOT NULL,
    CONSTRAINT ck_repuestos_existencias CHECK ((existencias >= 0)),
    CONSTRAINT ck_repuestos_precio CHECK ((precio >= (0)::numeric))
);


--
-- Name: vehiculos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehiculos (
    placa character varying(6) NOT NULL,
    marca character varying(50) NOT NULL,
    modelo character varying(50) NOT NULL,
    anio integer NOT NULL,
    vin character varying(17),
    documento_cliente character varying(20) NOT NULL
);


--
-- Name: mano_obra mano_obra_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mano_obra
    ADD CONSTRAINT mano_obra_pkey PRIMARY KEY (id_mano_obra);


--
-- Name: clientes pk_clientes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT pk_clientes PRIMARY KEY (documento);


--
-- Name: detalle_repuestos pk_detalle_repuesto; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_repuestos
    ADD CONSTRAINT pk_detalle_repuesto PRIMARY KEY (numero_orden, codigo_repuesto);


--
-- Name: ordenes_trabajo pk_ordenes_trabajo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes_trabajo
    ADD CONSTRAINT pk_ordenes_trabajo PRIMARY KEY (numero_orden);


--
-- Name: repuestos pk_repuestos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repuestos
    ADD CONSTRAINT pk_repuestos PRIMARY KEY (codigo);


--
-- Name: vehiculos pk_vehiculos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehiculos
    ADD CONSTRAINT pk_vehiculos PRIMARY KEY (placa);


--
-- Name: detalle_repuestos fk_detalle_repuesto_ordenes; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_repuestos
    ADD CONSTRAINT fk_detalle_repuesto_ordenes FOREIGN KEY (numero_orden) REFERENCES public.ordenes_trabajo(numero_orden);


--
-- Name: detalle_repuestos fk_detalle_repuestos_repuestos; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_repuestos
    ADD CONSTRAINT fk_detalle_repuestos_repuestos FOREIGN KEY (codigo_repuesto) REFERENCES public.repuestos(codigo);


--
-- Name: ordenes_trabajo fk_ordenes_trabajo_vehiculos; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes_trabajo
    ADD CONSTRAINT fk_ordenes_trabajo_vehiculos FOREIGN KEY (placa) REFERENCES public.vehiculos(placa);


--
-- Name: vehiculos fk_vehiculos_clientes; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehiculos
    ADD CONSTRAINT fk_vehiculos_clientes FOREIGN KEY (documento_cliente) REFERENCES public.clientes(documento);


--
-- Name: mano_obra mano_obra_numero_orden_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mano_obra
    ADD CONSTRAINT mano_obra_numero_orden_fkey FOREIGN KEY (numero_orden) REFERENCES public.ordenes_trabajo(numero_orden);


--
-- PostgreSQL database dump complete
--

\unrestrict dICQeqiYgCs5QwipfNXsUAD9BYIi1AmUIlmiTXqrDg8QQigvnfxfgxlgnvcPquJ

